<?php  get_header() ?>



    <section class="pt-4">
      <div class="container">
      <div class="row align-items-end">
        <div class="img col ">
          <img src="<?php echo get_stylesheet_directory_uri();?>/img/flower.jpg" class="img-fluid" alt="" />
        </div>

        <div class=" col exposection">
          <h3 class="expo">E2 Expo is back!</h3>
          <p class="p">
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quae
            soluta ullam rerum voluptatum ex nam aut ab iste accusamus
            molestiae, earum quia suscipit quos sequi praesentium rem id modi
            corporis!
          </p>

          <input class="button" type="button" value=" About E2" />
          <ul class="ultag">
            <li>Rose</li>
            <li>Lotus</li>
            <li>Sun Flower</li>
          </ul>
        </div>
      </div>
    </div>
    </section>

    <section>
      <div class="container">
      <div class="row align-items-end">
        <h2 class="loremipsum">What is Lorem Ipsum ?</h2>
        <p class="p">
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Inventore
          assumenda perspiciatis molestiae doloremque unde ad eveniet pariatur
          corrupti ex quae. Velit molestias vero vitae, dignissimos
          exercitationem porro expedita iste natus, voluptas rem atque aliquam
          libero modi temporibus esse incidunt dicta aspernatur quidem
          quibusdam, labore ipsam aperiam? Asperiores itaque, magnam deserunt
          eos expedita veniam delectus accusamus maxime! Harum impedit ipsam
          optio fugiat perferendis, cumque commodi maxime aut doloribus aliquam.
          Incidunt, perferendis similique? Explicabo ipsam nisi, ut voluptates
          voluptas minima labore temporibus culpa repellat veniam molestiae
          adipisci animi at, ipsa dolore repudiandae blanditiis officiis laborum
          commodi odit. Vitae sapiente quaerat animi beatae!
        </p>
        </div>
        </div>
    </section>
    <?php  get_footer();   ?>
  </body>
</html>
